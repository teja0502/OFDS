import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ProductService } from 'src/app/services/product.service';
import { SnachbarService } from 'src/app/services/snachbar.service';
import { UserpurchaseService } from 'src/app/services/userpurchase.service';
import { GlobalConstants } from 'src/app/shared/global-constants';
import { ViewOrderProductsComponent } from '../dialog/view-order-products/view-order-products.component';

@Component({
  selector: 'app-new-orders',
  templateUrl: './new-orders.component.html',
  styleUrls: ['./new-orders.component.scss']
})
export class NewOrdersComponent implements OnInit {
  displayedColumns: string[] = ['name','address', 'ucontact', 'purchaseType', 'amount','tranxid', 'view'];
  dataSource: any;
  responseMessage: any;
  constructor(
    private userpurchaseService: UserpurchaseService,
    private ngxService: NgxUiLoaderService,
    private dialog: MatDialog,
    private snachbarService: SnachbarService,
    private router: Router) { }

  ngOnInit(): void {
    this.ngxService.start();
    this.tableData();
  }

  tableData() {
    this.userpurchaseService.getrecord(localStorage.getItem('id')?.toString(),"Order Placed").subscribe((response: any) => {
      this.ngxService.stop();
      this.dataSource = new MatTableDataSource(response);
    }, (error: any) => {
      this.ngxService.stop();
      console.log(error.error?.message);
      if (error.error?.message) {
        this.responseMessage = error.error?.message;
      }
      else {
        this.responseMessage = GlobalConstants.genericError;
      }
      this.snachbarService.openSnackBar(this.responseMessage, GlobalConstants.error);
    })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  handleViewAction(values: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      productDetails: values.pdata
    };
    dialogConfig.width = "100%";
    const dialogRef = this.dialog.open(ViewOrderProductsComponent, dialogConfig);
    this.router.events.subscribe(() => {
      dialogRef.close();
    });
  }

  handleChangeStatus(value:any){
    var data = {
      purchaseId: value.purchaseId.toString(),
      status:'Preparing'
    }
    this.userpurchaseService.updatestatus(data).subscribe((response: any) => {
      this.responseMessage = response.message;
      this.snachbarService.openSnackBar(this.responseMessage, "success");
      this.tableData();
    }, (error) => {
      console.log(error);
      if (error.error?.message) {
        this.responseMessage = error.error?.message;
      }
      else
        this.responseMessage = GlobalConstants.genericError;
      this.snachbarService.openSnackBar(this.responseMessage, GlobalConstants.error);
    });
  }
}

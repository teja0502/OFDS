import { Routes } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { RouteGuardService } from '../services/route-guard.service';
import { CompletedOrdersComponent } from './completed-orders/completed-orders.component';

import { ManageCategoryComponent } from './manage-category/manage-category.component';
import { ManageProductComponent } from './manage-product/manage-product.component';
import { ManageRestaurantComponent } from './manage-restaurant/manage-restaurant.component';
import { NewOrdersComponent } from './new-orders/new-orders.component';
import { ProcessingOrdersComponent } from './processing-orders/processing-orders.component';
import { ViewRestaurantComponent } from './view-restaurant/view-restaurant.component';
import { YourOrdersComponent } from './your-orders/your-orders.component';


export const MaterialRoutes: Routes = [
  {
    path: 'category',
    component: ManageCategoryComponent,
    canActivate: [RouteGuardService],
    data: {
      expectedRole: ['restro']
    }
  },
  {
    path: 'product',
    component: ManageProductComponent,
    canActivate: [RouteGuardService],
    data: {
      expectedRole: ['restro']
    }
  },
  {
    path: 'restaurant',
    component: ManageRestaurantComponent,
    canActivate: [RouteGuardService],
    data: {
      expectedRole: ['admin']
    }
  },
  {
    path: 'restaurants',
    component: ViewRestaurantComponent,
    canActivate: [RouteGuardService],
    data: {
      expectedRole: ['user']
    }
  },
  {
    path: 'orders',
    component: YourOrdersComponent,
    canActivate: [RouteGuardService],
    data: {
      expectedRole: ['user']
    }
  },
  {
    path: 'new',
    component: NewOrdersComponent,
    canActivate: [RouteGuardService],
    data: {
      expectedRole: ['restro']
    }
  },
  {
    path: 'preparing',
    component: ProcessingOrdersComponent,
    canActivate: [RouteGuardService],
    data: {
      expectedRole: ['restro']
    }
  },
  {
    path: 'completed',
    component: CompletedOrdersComponent,
    canActivate: [RouteGuardService],
    data: {
      expectedRole: ['restro']
    }
  },
  { path: '**', component: DashboardComponent }
];

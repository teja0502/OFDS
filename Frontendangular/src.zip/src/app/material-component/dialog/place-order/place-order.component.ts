import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ProductService } from 'src/app/services/product.service';
import { SnachbarService } from 'src/app/services/snachbar.service';
import { GlobalConstants } from 'src/app/shared/global-constants';
import { OrderDetailsComponent } from '../order-details/order-details.component';
import { ViewImageComponent } from '../view-image/view-image.component';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.scss']
})
export class PlaceOrderComponent implements OnInit {
  displayedColumns: string[] = ['name', 'categoryName', 'description', 'price', 'edit'];
  cartDisplayedColumns: string[] = ['name', 'category', 'price', 'quantity', 'total', 'edit'];
  dataSource: any;
  cartDataSource:any= [];
  responseMessage:any;
  totalAmount:any = 0;

  constructor(@Inject(MAT_DIALOG_DATA) public dialogData: any,
  private productService: ProductService,
    private ngxService: NgxUiLoaderService,
    private dialog: MatDialog,
    private snachbarService: SnachbarService,
    private router: Router,
    public dialogRef: MatDialogRef<PlaceOrderComponent>,) { }

  ngOnInit(): void {
    this.tableData();
  }

  tableData() {
    this.productService.getallproduct(this.dialogData.data.id,true).subscribe((response: any) => {
      this.ngxService.stop();
      this.dataSource = new MatTableDataSource(response);
    }, (error: any) => {
      this.ngxService.stop();
      console.log(error.error?.message);
      if (error.error?.message) {
        this.responseMessage = error.error?.message;
      }
      else {
        this.responseMessage = GlobalConstants.genericError;
      }
      this.snachbarService.openSnackBar(this.responseMessage, GlobalConstants.error);
    })
  }

  addToCart(product:any){
    var productName = this.cartDataSource.find((e: { id: number; }) => e.id === product.id);
    if (productName === undefined) {
      this.totalAmount = this.totalAmount+product.price;
      this.cartDataSource.push({id: product.id, name: product.name, category: product.categoryName, quantity: 1, price: product.price, total: product.price });
      this.cartDataSource = [...this.cartDataSource];
      this.snachbarService.openSnackBar(GlobalConstants.productAdded, "success");
    }
    else {
      this.snachbarService.openSnackBar(GlobalConstants.productExistError, GlobalConstants.error);
    }
  }

  increment(product:any){
    var product = this.cartDataSource.find((e: { id: number; }) => e.id === product.id);
    product.quantity= product.quantity+1;
    product.total = product.total +product.price;
    this.totalAmount = this.totalAmount +product.price;
  }
  
  decrement(product:any){
    var product = this.cartDataSource.find((e: { id: number; }) => e.id === product.id);
    product.quantity= product.quantity-1;
    product.total = product.total -product.price;
    this.totalAmount = this.totalAmount -product.price;
  }

  handleDeleteAction(value: any, element: any) {
    this.totalAmount = this.totalAmount - element.total;
    this.cartDataSource.splice(value, 1);
    this.cartDataSource = [...this.cartDataSource];
    this.snachbarService.openSnackBar(GlobalConstants.productRemoved, '');
  }

  validateSubmit() {
    if (this.totalAmount === 0) {
      return true;
    }
    else
      return false;
  }

  submit(){
      const dialogConfig = new MatDialogConfig();
      dialogConfig.data = {
        amount: this.totalAmount,
        pdata: this.cartDataSource,
        restroId: this.dialogData.data.id
      };
      dialogConfig.width = "850px";
      const dialogRef = this.dialog.open(OrderDetailsComponent, dialogConfig);
      this.router.events.subscribe(() => {
        dialogRef.close();
      });
      const sub = dialogRef.componentInstance.onSubmitOrderDetails.subscribe(
        (response) => {
          this.dialogRef.close();
          this.router.navigate(['/ofds/orders']);
        }
      );
  }

  handleViewImageAction(values: any){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      action: 'Edit',
      data: values
    };
    dialogConfig.maxWidth= '80vw',
    dialogConfig.maxHeight= '80vh',
    dialogConfig.height= '80%',
    dialogConfig.width= '80%'
    const dialogRef = this.dialog.open(ViewImageComponent, dialogConfig);
    this.router.events.subscribe(() => {
      dialogRef.close();
    });
  }

}

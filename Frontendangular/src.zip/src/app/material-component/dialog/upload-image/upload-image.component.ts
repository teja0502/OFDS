import { HttpClient } from '@angular/common/http';
import { Component, OnInit, EventEmitter, Inject, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CategoryService } from 'src/app/services/category.service';
import { ProductService } from 'src/app/services/product.service';
import { SnachbarService } from 'src/app/services/snachbar.service';
import { GlobalConstants } from 'src/app/shared/global-constants';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-upload-image',
  templateUrl: './upload-image.component.html',
  styleUrls: ['./upload-image.component.scss']
})
export class UploadImageComponent implements OnInit {
  url = environment.apiUrl;
  onAddProduct = new EventEmitter();
  onEditProduct = new EventEmitter();
  productForm: any = FormGroup;
  dialogAction: any = "Add";
  action: any = "Add";
  responseMessage: any;
  categorys: any = [];
  SERVER_URL: any;
  test: any;

  constructor(@Inject(MAT_DIALOG_DATA) public dialogData: any,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<UploadImageComponent>,
    private categoryService: CategoryService,
    private snachbarService: SnachbarService,
    private httpClient: HttpClient
  ) { }

  ngOnInit() {
    this.productForm = this.formBuilder.group({
      profile: [null, Validators.required]
    });
    if (this.dialogData.action === 'Edit') {
      this.dialogAction = "Edit";
      this.action = "Update";
    }
    this.tableData();
  }

  handleSubmit() {
    this.test = localStorage.getItem('email')
    this.SERVER_URL = this.url + "/product/uploadimage";
    const formData = new FormData();
    var formData1 = this.productForm.value;
    console.log(formData);
    var data: any = {
      name: formData1.name,
      categoryId: formData1.categoryId,
      price: formData1.price,
      description: formData1.description,
      email: this.test
    }
    formData.append('multipartFile', this.productForm.get('profile').value);
    formData.append('email', this.test)
    formData.append('fileName', this.dialogData.data.productId)

    this.httpClient.post<any>(this.SERVER_URL, formData).subscribe(
      (response) => {
        this.dialogRef.close();
        this.onEditProduct.emit();
        this.responseMessage = response.message;
        this.snachbarService.openSnackBar(this.responseMessage, "success");
      },
      (error) => {
        console.log(error);
        if (error.error?.message) {
          this.responseMessage = error.error?.message;
        }
        else
          this.responseMessage = GlobalConstants.genericError;
        this.snachbarService.openSnackBar(this.responseMessage, GlobalConstants.error);
      },
    );

  }

  onFileSelect(event: any) {
    console.log("TEst");
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.productForm.get('profile').setValue(file);
    }
  }

  tableData() {
    this.categoryService.getcategory().subscribe((response: any) => {
      this.categorys = response;
    }, (error: any) => {
      console.log(error);
      if (error.error?.message) {
        this.responseMessage = error.error?.message;
      }
      else
        this.responseMessage = GlobalConstants.genericError;
      this.snachbarService.openSnackBar(this.responseMessage, GlobalConstants.error);
    })
  }
}

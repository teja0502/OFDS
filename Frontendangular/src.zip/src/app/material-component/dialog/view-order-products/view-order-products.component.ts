import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-view-order-products',
  templateUrl: './view-order-products.component.html',
  styleUrls: ['./view-order-products.component.scss']
})
export class ViewOrderProductsComponent implements OnInit {
  displayedColumns: string[] = ['name','category', 'price', 'quantity','total'];
  dataSource: any;
  name:any;
  email:any;
  contactNumber:any;
  paymentMethod:any;
  constructor(@Inject(MAT_DIALOG_DATA) public dialogData: any,
    public dialogRef: MatDialogRef<ViewOrderProductsComponent>
  ) { }

  ngOnInit() {
    this.dataSource = JSON.parse(this.dialogData.productDetails);
  }
}

import { Component, OnInit, EventEmitter, Inject, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { CategoryService } from 'src/app/services/category.service';
import { SnachbarService } from 'src/app/services/snachbar.service';
import { UserpurchaseService } from 'src/app/services/userpurchase.service';
import { GlobalConstants } from 'src/app/shared/global-constants';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.scss']
})
export class OrderDetailsComponent implements OnInit {
  onAddProduct = new EventEmitter();
  onSubmitOrderDetails = new EventEmitter();
  categoryForm: any = FormGroup;

  responseMessage: any;
  constructor(@Inject(MAT_DIALOG_DATA) public dialogData: any,
    private formBuilder: FormBuilder,
    private userpurchaseService: UserpurchaseService,
    public dialogRef: MatDialogRef<OrderDetailsComponent>,
    private snachbarService: SnachbarService,
    private ngxService: NgxUiLoaderService
  ) { }

  ngOnInit() {
    this.categoryForm = this.formBuilder.group({
      ptype: [null, [Validators.required]],
      tranxid: [null, []],
      address: [null, [Validators.required]],
      ucontact: [null,[Validators.required]]
    });
  }

  handleSubmit() {
      this.add();
  }

  add() {
    var formData = this.categoryForm.value;
    var data = {
      amount: this.dialogData.amount?.toString(),
      pdata: JSON.stringify(this.dialogData.pdata),
      restroId: this.dialogData.restroId?.toString(),
      userid: localStorage.getItem('id')?.toString(),
      ptype: formData.ptype,
      tranxid: formData.tranxid,
      address: formData.address,
      ucontact: formData.ucontact
    }
    this.userpurchaseService.purchase(data).subscribe((response: any) => {
      this.ngxService.stop();
      this.dialogRef.close();
      this.onSubmitOrderDetails.emit();
      this.responseMessage = response.message;
      this.snachbarService.openSnackBar(this.responseMessage, "success");
    }, (error) => {
      this.ngxService.stop();
      this.dialogRef.close();
      console.log(error);
      if (error.error?.message) {
        this.responseMessage = error.error?.message;
      }
      else
        this.responseMessage = GlobalConstants.genericError;
      this.snachbarService.openSnackBar(this.responseMessage, GlobalConstants.error);
    });
  }
}

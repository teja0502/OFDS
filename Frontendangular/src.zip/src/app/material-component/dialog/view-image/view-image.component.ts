import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-view-image',
  templateUrl: './view-image.component.html',
  styleUrls: ['./view-image.component.scss']
})
export class ViewImageComponent implements OnInit {

  test: any;
  imageToShow: any;
  // isImageLoading: boolean;
  constructor(@Inject(MAT_DIALOG_DATA) public dialogData: any, private httpClient: HttpClient, private productService: ProductService, private sanitizer: DomSanitizer) { }

  ngOnInit(): void {
    // this.test=this.getImage();
    console.log
    this.getImageFromService();
  }



  createImageFromBlob(image: Blob) {
    let reader = new FileReader();
    reader.addEventListener("load", () => {
      this.imageToShow = reader.result;
      this.imageToShow = this.sanitizer.bypassSecurityTrustUrl(this.imageToShow);
    }, false);

    if (image) {
      console.log(image);
      reader.readAsDataURL(image);
    }
  }

  getImageFromService() {
    console.log(this.dialogData);
    //  this.isImageLoading = true;
    var data = {
      filePath:this.dialogData.data.filePath
    }
    this.productService.getImage(data).subscribe(data => {
      //  console.log(data);
      this.createImageFromBlob(data);
      //  this.isImageLoading = false;
    }, error => {
      //  this.isImageLoading = false;
      console.log(error);
    });
  }
}

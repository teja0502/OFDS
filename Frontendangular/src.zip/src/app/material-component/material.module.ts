import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { CdkTableModule } from '@angular/cdk/table';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';

import { MaterialRoutes } from './material.routing';
import { MaterialModule } from '../shared/material-module';
import { ManageProductComponent } from './manage-product/manage-product.component';
import { ProductComponent } from './dialog/product/product.component';
import { ManageCategoryComponent } from './manage-category/manage-category.component';
import { CategoryComponent } from './dialog/category/category.component';
import { ConfirmationComponent } from './dialog/confirmation/confirmation.component';
import { ManageRestaurantComponent } from './manage-restaurant/manage-restaurant.component';
import { RestaurantComponent } from './dialog/restaurant/restaurant.component';
import { ViewRestaurantComponent } from './view-restaurant/view-restaurant.component';
import { PlaceOrderComponent } from './dialog/place-order/place-order.component';
import { OrderDetailsComponent } from './dialog/order-details/order-details.component';
import { YourOrdersComponent } from './your-orders/your-orders.component';
import { ViewOrderProductsComponent } from './dialog/view-order-products/view-order-products.component';
import { NewOrdersComponent } from './new-orders/new-orders.component';
import { ProcessingOrdersComponent } from './processing-orders/processing-orders.component';
import { CompletedOrdersComponent } from './completed-orders/completed-orders.component';
import { ViewImageComponent } from './dialog/view-image/view-image.component';
import { UploadImageComponent } from './dialog/upload-image/upload-image.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(MaterialRoutes),
    MaterialModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    CdkTableModule
  ],
  providers: [],
  declarations: [
    ManageProductComponent,
    ProductComponent,
    ManageCategoryComponent,
    CategoryComponent,
    ConfirmationComponent,
    ManageRestaurantComponent,
    RestaurantComponent,
    ViewRestaurantComponent,
    PlaceOrderComponent,
    OrderDetailsComponent,
    YourOrdersComponent,
    ViewOrderProductsComponent,
    NewOrdersComponent,
    ProcessingOrdersComponent,
    CompletedOrdersComponent,
    ViewImageComponent,
    UploadImageComponent
    
  ]
})
export class MaterialComponentsModule {}

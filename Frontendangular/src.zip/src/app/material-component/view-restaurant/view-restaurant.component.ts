import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { RestroService } from 'src/app/services/restro.service';
import { SnachbarService } from 'src/app/services/snachbar.service';
import { GlobalConstants } from 'src/app/shared/global-constants';
import { PlaceOrderComponent } from '../dialog/place-order/place-order.component';

@Component({
  selector: 'app-view-restaurant',
  templateUrl: './view-restaurant.component.html',
  styleUrls: ['./view-restaurant.component.scss']
})
export class ViewRestaurantComponent implements OnInit {
  dataSource:any;
  responseMessage:any;
  constructor(private dialog: MatDialog,
    private router: Router,
    private restroService: RestroService,
    private ngxService: NgxUiLoaderService,
    private snachbarService: SnachbarService) { }

  ngOnInit(): void {
    this.tableData();
  }

  tableData() {
    this.restroService.getrestro().subscribe((response: any) => {
      this.ngxService.stop();
      this.dataSource = response;
    }, (error: any) => {
      this.ngxService.stop();
      console.log(error.error?.message);
      if (error.error?.message) {
        this.responseMessage = error.error?.message;
      }
      else {
        this.responseMessage = GlobalConstants.genericError;
      }
      this.snachbarService.openSnackBar(this.responseMessage, GlobalConstants.error);
    })
  }

  viewProducts(restaurant:any){
    console.log(restaurant);
      const dialogConfig = new MatDialogConfig();
      dialogConfig.data = {
        action: 'Edit',
        data: restaurant
      };
      dialogConfig.width = "850px";
      dialogConfig.maxWidth= '100vw',
      dialogConfig.maxHeight= '100vh',
      dialogConfig.height= '100%',
      dialogConfig.width= '100%'
      const dialogRef = this.dialog.open(PlaceOrderComponent, dialogConfig);
      this.router.events.subscribe(() => {
        dialogRef.close();
      });
      // const sub = dialogRef.componentInstance.onEditProduct.subscribe(
      //   (response) => {
      //     this.tableData();
      //   }
      // );
  }

}

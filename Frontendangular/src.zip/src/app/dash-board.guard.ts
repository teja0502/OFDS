import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DashBoardGuard implements CanActivate {
  constructor(private router: Router) {}
  
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

  const email =  sessionStorage.getItem("Username") || null;
  const password =  sessionStorage.getItem("Password") || null;
  if(email && password){
    console.log(`${email}, and password: ${password}`);
    return true;
  }else {
    this.router.navigate(['ofds']);
    return false
  }


    // return true;
  }
  
}

import { Injectable } from '@angular/core';

export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
  role: string;
}

const MENUITEMS = [
  //Admin
  { state: 'dashboard', name: 'Dashboard', type: 'link', icon: 'dashboard',role: '' },
  // { state: 'category', type: 'link', name: 'Manage Category', icon: 'category',role: 'admin' },
  // { state: 'product', type: 'link', name: 'Manage Product', icon: 'inventory_2',role: 'admin' },
  // { state: 'order', type: 'link', name: 'Manage Order', icon: 'inventory_2',role: 'admin' },
  // { state: 'bill', type: 'link', name: 'View Bill', icon: 'import_contacts',role: 'admin' },
  // { state: 'user', type: 'link', name: 'Manage Users', icon: 'import_contacts',role: 'admin' },
  { state: 'restaurant', type: 'link', name: 'Manage Restaurant', icon: 'table_restaurant',role: 'admin' },
  //User
  { state: 'restaurants', type: 'link', name: 'Restaurants', icon: 'inventory_2',role: 'user' },
  { state: 'orders', type: 'link', name: 'Your Orders', icon: 'inventory_2',role: 'user' },
  // { state: 'bill', type: 'link', name: 'View Bill', icon: 'import_contacts',role: 'user' },

  //Restro
  { state: 'category', type: 'link', name: 'Manage Category', icon: 'category',role: 'restro' },
  { state: 'product', type: 'link', name: 'Manage Product', icon: 'inventory_2',role: 'restro' },
  { state: 'new', type: 'link', name: 'New Orders', icon: 'trip_origin',role: 'restro' },
  { state: 'preparing', type: 'link', name: 'Preparing Orders', icon: 'incomplete_circle',role: 'restro' },
  { state: 'completed', type: 'link', name: 'Completed Orders', icon: 'check_circle',role: 'restro' },
];

@Injectable()
export class MenuItems {
  getMenuitem(): Menu[] {
    return MENUITEMS;
  }
}

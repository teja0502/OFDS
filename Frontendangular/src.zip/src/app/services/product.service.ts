import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  url = environment.apiUrl;

  constructor(private httpClient: HttpClient) { }

  addproduct(data: any) {
    return this.httpClient.post(this.url +
      "/product/addproduct", data, {
      headers: new HttpHeaders().set('Content-Type', "multipart/form-data")
    })
  }

  updateproduct(data: any) {
    return this.httpClient.post(this.url +
      "/product/updateproduct", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  getallproduct(id:any,status:any) {
    return this.httpClient.get(this.url + "/product/getallproduct/"+id+"?status="+status);
  }

  updatestatus(data: any) {
    return this.httpClient.post(this.url +
      "/product/updatestatus", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  deleteproduct(id: any) {
    return this.httpClient.post(this.url +
      "/product/deleteproduct/" + id, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  
  getImage(data:any): Observable<Blob> {
    return this.httpClient.post(this.url+'/product/getImage',data, {responseType: "blob"});
}
}

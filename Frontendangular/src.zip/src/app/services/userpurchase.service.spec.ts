import { TestBed } from '@angular/core/testing';

import { UserpurchaseService } from './userpurchase.service';

describe('UserpurchaseService', () => {
  let service: UserpurchaseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserpurchaseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

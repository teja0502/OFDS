import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserpurchaseService {
  url = environment.apiUrl;

  constructor(private httpClient: HttpClient) { }

  purchase(data: any) {
    return this.httpClient.post(this.url +
      "/userpurchase/purchase", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  getrecord(userId:any,status:any) {
    return this.httpClient.get(this.url + "/userpurchase/getrecord?userId="+userId+"&status="+status);
  }

  updatestatus(data: any) {
    return this.httpClient.post(this.url +
      "/userpurchase/updatestatus", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }
}

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router } from '@angular/router';
import jwt_decode from "jwt-decode";
import { GlobalConstants } from '../shared/global-constants';
import { SnachbarService } from './snachbar.service';

@Injectable({
  providedIn: 'root'
})
export class RouteGuardService implements CanActivate {
  constructor(public router: Router, 
     private snachbarService: SnachbarService) { }
     
  canActivate(route: ActivatedRouteSnapshot): boolean {

    let expectedRoleArray = route.data;
    expectedRoleArray = expectedRoleArray.expectedRole;

    const role: any = localStorage.getItem('role');

    let checkRole = false;

    for (let i = 0; i < expectedRoleArray.length; i++) {
      if (expectedRoleArray[i] == role) {
        checkRole = true;
      }
    }

    if (role == 'user' || role == 'admin' || role == 'restro') {
      if (checkRole) {
        return true;
      }
      this.snachbarService.openSnackBar(GlobalConstants.unauthroized, GlobalConstants.error);
      this.router.navigate(['/ofds/dashboard']);
      return false;
    }
    else {
      this.router.navigate(['/']);
      localStorage.clear();
      return false;
    }
  }

}

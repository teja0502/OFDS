import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RestroService {
  url = environment.apiUrl;

  constructor(private httpClient: HttpClient) { }

  addrestro(data: any) {
    return this.httpClient.post(this.url +
      "/restro/addrestro", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  updaterestro(data: any) {
    return this.httpClient.post(this.url +
      "/restro/updaterestro", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  getrestro() {
    return this.httpClient.get(this.url + "/restro/getrestro");
  }
}

import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  url = environment.apiUrl;

  constructor(private httpClient: HttpClient) { }

  addcategory(data: any) {
    return this.httpClient.post(this.url +
      "/category/addcategory", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  updatecategory(data: any) {
    return this.httpClient.post(this.url +
      "/category/updatecategory", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  getcategory() {
    return this.httpClient.get(this.url + "/category/getcategory/"+localStorage.getItem('id'));
  }
}

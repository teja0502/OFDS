import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  url = environment.apiUrl;

  constructor(private httpClient: HttpClient) { }

  login(data: any) {
    return this.httpClient.post(this.url +
      "/appuser/login", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  signup(data: any) {
    return this.httpClient.post(this.url +
      "/appuser/signup", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  forgotPassword(data: any) {
    return this.httpClient.post(this.url +
      "/user/forgotPassword/", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  getUsers() {
    return this.httpClient.get(this.url + "/user/get/");
  }

  checkToken() {
    return this.httpClient.get(this.url + "/user/checkToken");
  }

  update(data: any) {
    return this.httpClient.patch(this.url +
      "/user/update/", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }

  changePassword(data: any) {
    return this.httpClient.post(this.url +
      "/user/changePassword/", data, {
      headers: new HttpHeaders().set('Content-Type', "application/json")
    })
  }
}
